public class A{

	public int a;
	private int b;

	public void method1(){

	}

	public int menthod2(float f){

	}

}

