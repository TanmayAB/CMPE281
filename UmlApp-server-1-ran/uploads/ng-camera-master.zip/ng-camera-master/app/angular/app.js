(function(angular) {
    'use strict';

    angular
        .module('camera', []);

})(angular);
