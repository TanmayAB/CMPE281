var fs = require('fs');
var unzip = require('unzip');
var exec = require('child_process').exec;

fs.createReadStream('./output.zip').pipe(unzip.Extract({ path: '.' }));

var complileit = "java -jar umlparser.jar C:\\Users\\admin\\Desktop\\ziptest\\output finalp";

exec(compileit, function(error, stdout, stderr) {
});
